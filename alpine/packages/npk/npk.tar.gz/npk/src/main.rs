fn main() {
    println!("Hello, world from NPK!");
}
